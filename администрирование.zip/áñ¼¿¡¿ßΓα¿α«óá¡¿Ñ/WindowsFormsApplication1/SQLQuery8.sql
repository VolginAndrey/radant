﻿Update logpar
set tries = tries+1
where Logg = 'a'